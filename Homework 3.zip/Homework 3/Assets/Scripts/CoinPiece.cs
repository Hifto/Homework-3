﻿using UnityEngine;
using System.Collections;

public class CoinPiece : MonoBehaviour {

    public Transform collectedPiece;
}
