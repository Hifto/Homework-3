﻿using UnityEngine;
using System.Collections;

public class LevelPiece : MonoBehaviour {

	public Transform exitPoint;
}
